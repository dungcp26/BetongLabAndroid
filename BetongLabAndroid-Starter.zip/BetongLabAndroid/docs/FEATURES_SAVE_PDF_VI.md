# Tính năng lưu cấp phối và xuất PDF

- Lưu cấp phối cục bộ trên WebView localStorage; không cần mạng/tài khoản.
- Danh sách cấp phối: nạp lại, xuất PDF, xóa có xác nhận.
- Nạp lại để sửa thông số; lưu lần nữa tạo bản lưu mới.
- PDF dùng chức năng chia sẻ Android, file nằm trong cache của ứng dụng.
- Nội dung PDF cảnh báo kết quả mô phỏng chỉ tham khảo, không thay thế thí nghiệm thực tế.

**Lưu ý:** Bản PDF hiện tạo bằng native Android PDF canvas và dùng font hệ thống; các nhãn được chuẩn hóa không dấu ở PDF để tránh lỗi font trên một số máy.
