# Checklist phát hành Google Play

## Tài khoản & nhận diện
- [ ] Google Play Console đăng ký/hoàn tất xác minh
- [ ] Xác định applicationId/package name vĩnh viễn
- [ ] Tên app, mô tả ngắn/dài, email hỗ trợ
- [ ] Icon 512x512; ảnh feature graphic 1024x500; screenshots điện thoại

## Kỹ thuật
- [ ] Bundle AAB ký bằng upload key; backup keystore/credentials
- [ ] Target API 36
- [ ] Kiểm thử Android 8+ (API 24) và các máy phổ biến
- [ ] Kiểm thử offline và CDN fallback; hiện HTML đang dùng CDN
- [ ] Kiểm thử crash, accessibility, font/keyboard, biểu đồ, back button, TTS
- [ ] Hoàn thiện lưu cấp phối/lịch sử, export nếu hứa trong listing
- [ ] Thay test AdMob App ID và Ad Unit ID bằng ID thật
- [ ] Test quảng cáo bằng test devices

## Chính sách
- [ ] Privacy policy URL công khai
- [ ] Data safety form khớp SDK thực tế
- [ ] Ads declaration, content rating, target audience
- [ ] Consent flow nếu cần cho vùng/SDK/đối tượng
- [ ] App access instructions (nếu có nội dung khóa)
- [ ] Disclaimer: kết quả mô phỏng không thay thế thí nghiệm/tiêu chuẩn nghiệm thu

## Phát hành
- [ ] Internal testing
- [ ] Closed testing theo yêu cầu của Play Console/account
- [ ] Sửa lỗi và gửi review
- [ ] Production rollout theo tỷ lệ nhỏ
- [ ] Theo dõi crash, ANR, đánh giá và AdMob readiness
