# Chính sách quyền riêng tư – Bê Tông Lab

**Bản mẫu, phải hoàn thiện và đăng lên URL công khai trước khi phát hành.**

Bê Tông Lab cung cấp công cụ mô phỏng/tra cứu về bê tông và vữa. Nhà phát triển cần cập nhật nội dung này chính xác theo các SDK, dữ liệu và tính năng thực tế trong bản phát hành.

## Dữ liệu
Mô tả rõ dữ liệu nào ứng dụng lưu trên thiết bị, dữ liệu nào được thu thập hoặc chia sẻ bởi SDK quảng cáo/analytics, mục đích, thời gian lưu, cách xóa và thông tin liên hệ nhà phát triển.

## Quảng cáo
Ứng dụng có thể sử dụng Google Mobile Ads (AdMob). Việc xử lý dữ liệu quảng cáo/định danh/consent phụ thuộc cấu hình SDK và các lựa chọn của người dùng. Cập nhật liên kết chính sách Google và phần khai báo Data safety phù hợp.

## Lưu trữ và xóa dữ liệu
Mô tả chính xác cơ chế lưu dữ liệu cấp phối/lịch sử và cách người dùng xóa dữ liệu.

## Liên hệ
Nhà phát triển: Đỗ Quang Dũng  
Email liên hệ: **[BỔ SUNG EMAIL]**

Ngày cập nhật: **[BỔ SUNG NGÀY]**
