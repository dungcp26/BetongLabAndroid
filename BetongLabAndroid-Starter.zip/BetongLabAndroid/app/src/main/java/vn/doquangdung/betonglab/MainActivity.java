package vn.doquangdung.betonglab;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import java.util.Locale;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.File;
import java.io.FileOutputStream;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.content.Intent;
import androidx.core.content.FileProvider;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MobileAds.initialize(this, initializationStatus -> {});
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("vi", "VN"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFFAFAF9);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.addJavascriptInterface(new NativeBridge(), "AndroidTTS");
        webView.addJavascriptInterface(new PdfBridge(), "AndroidPDF");
        root.addView(webView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        AdView adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111"); // Google test banner; replace before release
        root.addView(adView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        adView.loadAd(new AdRequest.Builder().build());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NativeBridge {
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> { if (ttsReady && text != null && !text.trim().isEmpty()) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "betonglab-tts"); });
        }
        @JavascriptInterface public void stop() { runOnUiThread(() -> { if (tts != null) tts.stop(); }); }
    }


    private class PdfBridge {
        @JavascriptInterface public void exportPdf(String json) {
            runOnUiThread(() -> createAndSharePdf(json));
        }
    }

    private void createAndSharePdf(String json) {
        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = document.startPage(info);
        Canvas canvas = page.getCanvas();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(0xFF172554); paint.setTextSize(20); paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        canvas.drawText("PHIẾU CẤP PHỐI - BÊ TÔNG LAB", 40, 48, paint);
        paint.setColor(0xFF333333); paint.setTextSize(12); paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        int y = 78;
        try {
            JSONObject o = new JSONObject(json);
            String name = o.optString("name", "Cap phoi");
            String date = o.optString("savedAt", "");
            String grade = o.optString("gradeLabel", o.optString("grade", ""));
            String aggregate = o.optString("aggregateLabel", o.optString("aggregate", ""));
            String test = o.optString("testLabel", o.optString("test", ""));
            String[] lines = {"Tên cấp phối: " + name, "Tác giả: Đỗ Quang Dũng", "Ngày tạo: " + date,
                "Loại/mác: " + grade, "Cốt liệu: " + aggregate, "Chỉ tiêu mô phỏng: " + test,
                "", "THÀNH PHẦN CHO 1 m³ (theo dữ liệu nhập)", "Xi măng: " + o.optString("cement") + " kg",
                "Nước: " + o.optString("water") + " L", "Cát: " + o.optString("sand") + " kg",
                "Đá/cốt liệu lớn: " + o.optString("aggregateMass") + " kg", "Tro bay/Silica fume: " + o.optString("ash") + " kg",
                "Phụ gia: " + o.optString("admix") + " L", "", "KẾT QUẢ MÔ PHỎNG"};
            for (String line : lines) { canvas.drawText(line, 40, y, paint); y += 20; }
            JSONObject m = o.optJSONObject("metrics");
            if (m != null) { String[] keys={"m1Title","m1","m2Title","m2","m3Title","m3","density","r28","waterproof","status"};
                for(String k:keys){String v=m.optString(k,""); if(!v.isEmpty()){canvas.drawText(v,40,y,paint);y+=20;}}
            }
            y += 10; paint.setColor(0xFF9A3412); paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            canvas.drawText("CẢNH BÁO: Kết quả chỉ tham khảo/mô phỏng, không thay thế",40,y,paint); y+=18;
            canvas.drawText("thí nghiệm thực tế và quy trình chấp nhận theo tiêu chuẩn.",40,y,paint);
        } catch(Exception e) { canvas.drawText("Du lieu phieu khong doc duoc.",40,y,paint); }
        document.finishPage(page);
        try {
            File dir = new File(getCacheDir(), "reports"); if(!dir.exists())dir.mkdirs();
            File file = new File(dir, "BetongLab-report-"+System.currentTimeMillis()+".pdf");
            FileOutputStream out = new FileOutputStream(file); document.writeTo(out); out.close(); document.close();
            android.net.Uri uri = FileProvider.getUriForFile(this, getPackageName()+".provider", file);
            Intent share = new Intent(Intent.ACTION_SEND); share.setType("application/pdf"); share.putExtra(Intent.EXTRA_STREAM, uri); share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "Chia se phieu PDF"));
        } catch(Exception e) { document.close(); android.widget.Toast.makeText(this,"Khong tao duoc PDF: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show(); }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onPause() { if (webView != null) webView.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (webView != null) webView.onResume(); }
    @Override protected void onDestroy() { if (webView != null) webView.destroy(); if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
