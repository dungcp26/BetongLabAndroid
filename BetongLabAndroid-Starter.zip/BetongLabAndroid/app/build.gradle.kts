plugins { id("com.android.application") }

android {
    namespace = "vn.doquangdung.betonglab"
    compileSdk = 36
    defaultConfig {
        applicationId = "vn.doquangdung.betonglab"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
