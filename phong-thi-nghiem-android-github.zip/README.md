# Phòng Thí Nghiệm Bê Tông Thực Chiến – Android (offline)

Web app được đóng gói bằng Capacitor, build bằng GitHub Actions. Mọi thư viện (Tailwind, Chart.js, font) nằm trong app nên chạy hoàn toàn offline.

## 1. Đưa lên GitHub
1. Tạo repo mới (nên để Private), upload toàn bộ thư mục này (nhớ cả thư mục `.github`).
2. Tab **Actions** → **Build Android** → **Run workflow**.
3. Khi xong, tải **apk-debug** về cài thử trên điện thoại (bật chế độ máy bay để kiểm tra offline).

## 2. Tạo khóa ký (làm 1 lần, giữ kỹ file này, mất là không cập nhật app được)
```
keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 upload.jks > upload.b64    # Windows: certutil -encode upload.jks upload.b64
```
Repo → Settings → Secrets and variables → Actions, thêm 4 secret:
`KEYSTORE_BASE64` (nội dung upload.b64), `KEY_ALIAS` (upload), `KEYSTORE_PASSWORD`, `KEY_PASSWORD`.

## 3. Lấy file lên Google Play
Chạy lại workflow → tải **aab-google-play** (file .aab). Trong Play Console tạo ứng dụng, bật Play App Signing, tải .aab lên.
Mỗi lần build `versionCode` tự tăng theo số lần chạy.

## Cần chuẩn bị cho Play Console
- Tài khoản nhà phát triển (phí 25 USD một lần).
- Chính sách quyền riêng tư (URL công khai). App không thu thập dữ liệu, dữ liệu chỉ lưu trên máy.
- Ảnh chụp màn hình, mô tả, phân loại nội dung, Data safety (khai "không thu thập").
- Tài khoản cá nhân mới thường phải chạy thử nghiệm kín với nhóm người thử trong một thời gian trước khi phát hành. Kiểm tra yêu cầu hiện hành trong Play Console.
- Đổi `appId` trong `capacitor.config.json` sang ID riêng của bạn trước khi phát hành lần đầu (không đổi được sau này).

## Ghi chú kỹ thuật
- `src/native-bridge.js`: trên Android, xuất PDF phiếu giao nhận mở bảng chia sẻ (Lưu/Zalo/Email). Phiếu nhật ký xuất file HTML để mở bằng Chrome rồi In/Lưu PDF, vì WebView không có chức năng in.
- Sửa nội dung app tại `src/index.html`.
