// Đóng gói web 100% offline: Tailwind (biên dịch sẵn) + Chart.js + font Inter/JetBrains Mono nội bộ.
import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const out = 'www';
fs.rmSync(out, { recursive: true, force: true });
for (const d of ['css', 'fonts', 'vendor']) fs.mkdirSync(path.join(out, d), { recursive: true });

fs.copyFileSync('src/index.html', path.join(out, 'index.html'));
fs.copyFileSync('src/native-bridge.js', path.join(out, 'native-bridge.js'));

// 1) Tailwind -> css/app.css
execSync('npx tailwindcss -c tailwind.config.js -i src/input.css -o www/css/app.css --minify', { stdio: 'inherit' });

// 2) Chart.js
const chartCandidates = ['node_modules/chart.js/dist/chart.umd.js', 'node_modules/chart.js/dist/chart.umd.min.js'];
const chart = chartCandidates.find(p => fs.existsSync(p));
if (!chart) throw new Error('Không tìm thấy chart.umd.js trong node_modules/chart.js/dist');
fs.copyFileSync(chart, path.join(out, 'vendor/chart.umd.js'));

// 3) Font (chỉ subset latin + vietnamese, woff2)
const want = [['inter', [400, 500, 600, 700, 800]], ['jetbrains-mono', [400, 600, 700]]];
let css = '';
for (const [name, weights] of want) {
  for (const w of weights) {
    const src = fs.readFileSync(`node_modules/@fontsource/${name}/${w}.css`, 'utf8');
    for (const block of src.match(/@font-face\s*{[^}]*}/g) || []) {
      if (!/latin(?!-ext)|vietnamese/.test(block) && !/\/\* (latin|vietnamese) \*\//.test(block)) continue;
      const m = block.match(/url\((\.\/files\/[^)]+?\.woff2)\)/);
      if (!m) continue;
      const file = path.basename(m[1]);
      if (!/-(latin|vietnamese)-/.test(file)) continue;
      fs.copyFileSync(`node_modules/@fontsource/${name}/files/${file}`, path.join(out, 'fonts', file));
      const fixed = block.replace(/src:[^;]+;/, `src: url(../fonts/${file}) format('woff2');`);
      css += fixed + '\n';
    }
  }
}
fs.writeFileSync(path.join(out, 'css/fonts.css'), css);
console.log('Build web xong -> www/');
