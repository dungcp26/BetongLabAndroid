/* Cầu nối cho bản Android (WebView): WebView không hỗ trợ tải blob / window.print / window.open để in.
   Trên trình duyệt thường file này không làm gì. */
(function () {
  const cap = window.Capacitor;
  if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return;
  const P = cap.Plugins || {};

  function blobToBase64(blob) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onloadend = () => res(String(r.result).split(',')[1]);
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  }
  async function saveAndShare(blob, fileName, title) {
    try {
      const data = await blobToBase64(blob);
      const saved = await P.Filesystem.writeFile({ path: fileName, data, directory: 'CACHE' });
      await P.Share.share({ title: title || fileName, url: saved.uri, dialogTitle: 'Lưu / Gửi file' });
    } catch (e) {
      if (!e || !/cancel/i.test(String(e.message || e))) alert('Không thể lưu/chia sẻ file: ' + (e && e.message ? e.message : e));
    }
  }

  // PDF phiếu giao nhận: lưu file rồi mở bảng chia sẻ (Lưu vào Drive, Zalo, Email, In...)
  window.triggerPdfDownload = function (blob, fileName) { saveAndShare(blob, fileName, fileName); };

  // Phiếu nhật ký: WebView không in được -> xuất file HTML (mở bằng Chrome, bấm In/Lưu PDF)
  window.exportMixPDF = function (rec) {
    const r = rec || (typeof buildRecordPayload === 'function' ? buildRecordPayload(window.editingRecordId) : null);
    if (!r) return;
    const html = buildPrintableHtmlDocument(r);
    const name = 'Phieu_Thi_Nghiem_' + String(r.mixCode || r.name || 'Cap_Phoi').replace(/[^a-zA-Z0-9_-]+/g, '_') + '.html';
    saveAndShare(new Blob([html], { type: 'text/html' }), name, 'Phiếu thí nghiệm');
  };

  // Nút "In Bản Này"
  window.print = function () {
    if (typeof activePrintMode !== 'undefined' && activePrintMode === 'delivery') exportDeliveryTicketPDF();
    else exportMixPDF(typeof activePrintRecord !== 'undefined' ? activePrintRecord : undefined);
  };
})();
