# Hướng dẫn build Bê Tông Lab chỉ bằng điện thoại

## Bước 1: Tạo tài khoản GitHub
1. Mở https://github.com trên trình duyệt điện thoại.
2. Đăng ký tài khoản miễn phí và xác minh email.
3. Tạo repository mới, đặt tên `betong-lab-android`, chọn Private (khuyến nghị), rồi Create repository.

## Bước 2: Đưa bộ build lên repository
1. Trong repository, chọn Add file > Upload files.
2. Upload file `BetongLabAndroid-Starter.zip`.
3. Tạo thư mục workflow: mở Add file > Create new file.
4. Tên file nhập đúng: `.github/workflows/android-build.yml`
5. Dán toàn bộ nội dung file `android-build.yml` trong gói này vào.
6. Commit changes.

## Bước 3: Chạy build
1. Mở tab Actions của repository.
2. Chọn workflow `Build Betong Lab Android`.
3. Nhấn `Run workflow` > `Run workflow`.
4. Chờ workflow chạy xanh (thường vài phút, tùy tải và tải dependencies).

## Bước 4: Tải APK về điện thoại
1. Mở lần chạy vừa hoàn tất trong Actions.
2. Kéo xuống phần Artifacts.
3. Tải `BetongLabAndroid-build` (file ZIP artifact).
4. Giải nén trên điện thoại, lấy APK debug để cài và thử.

## Lưu ý quan trọng
- Workflow hiện tạo APK debug để cài thử và AAB release chưa ký. AAB chưa ký không thể phát hành Play Store.
- Để phát hành, cần tạo khóa ký (keystore) và thiết lập ký release an toàn qua GitHub Secrets; không gửi khóa hoặc mật khẩu vào chat, không commit keystore lên repository.
- Cần kiểm tra, sửa lỗi ứng dụng và đóng gói thư viện web dùng ngoài vào assets để hỗ trợ offline trước khi phát hành.
- Đừng bật quảng cáo thật khi thử nghiệm; dùng test ads cho tới khi ứng dụng đã tuân thủ chính sách.
