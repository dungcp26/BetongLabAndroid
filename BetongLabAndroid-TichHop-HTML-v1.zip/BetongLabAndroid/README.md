# Bê Tông Lab – Android starter project

Project Android native wrapper cho HTML lab hiện tại. Target Android 16 / API 36, min API 24.

## Tình trạng
- Đã đưa HTML vào assets và thiết lập WebView.
- Native Android Text-to-Speech bridge: `window.AndroidTTS.speak(text)` và `window.AndroidTTS.stop()`.
- AdMob banner đang dùng **Google test ad unit**. Tuyệt đối không dùng test ID để phát hành.
- Tài nguyên HTML hiện phụ thuộc CDN Tailwind, Chart.js và Google Fonts; do đó các thư viện này cần Internet. Bước tiếp theo cần đóng gói nội bộ/offline và QA.
- Cấp phối/đầu ra trong app là mô phỏng, cần kiểm chứng chuyên môn, ghi rõ không thay thế thí nghiệm hiện trường/phòng lab.

## Build
1. Cài Android Studio bản mới, Android SDK Platform 36, JDK tương thích.
2. Mở thư mục project này trong Android Studio.
3. Chờ Gradle Sync; nếu SDK/Gradle chưa đủ, Android Studio gợi ý cài.
4. Chạy app trên thiết bị Android hoặc emulator.
5. Build > Generate Signed Bundle / APK > Android App Bundle (AAB), tạo keystore và lưu backup an toàn.

## Trước khi phát hành
- Thay applicationId nếu cần (phải xác định trước, vì package name cố định sau khi phát hành).
- Tạo AdMob app + banner ad unit riêng; thay App ID trong Manifest và Ad Unit ID trong MainActivity.
- Không bao giờ click quảng cáo thật của chính mình; test bằng test ads.
- Hoàn thiện privacy policy, Data safety, content rating, ads declaration, screenshots, icon, store listing.
- Test các thiết bị/kích cỡ màn hình, không mạng, mất mạng, xoay màn hình, back, TTS, lưu dữ liệu, crash.
- Kiểm tra Play Console closed testing yêu cầu áp dụng cho tài khoản.


## Tích hợp giao diện HTML v2.3
- `app/src/main/assets/index.html` đã được thay bằng file HTML Phòng Thí Nghiệm Vật Liệu Bê Tông & Vữa Thực Chiến v2.3.
- Đã thêm GitHub Actions tại `.github/workflows/android-build.yml` để tạo APK debug và AAB release unsigned.
- **Chưa phải bản offline hoàn chỉnh:** HTML v2.3 còn tải Tailwind CSS và Chart.js từ CDN. Khi không có Internet, phần giao diện/biểu đồ có thể không hoạt động đầy đủ.
- AAB hiện là bản unsigned; trước khi đưa lên Google Play cần cấu hình ký ứng dụng bằng upload key và bảo quản keystore.
- Cần kiểm thử lại chức năng xuất PDF, TTS, lưu dữ liệu và giao diện trên điện thoại sau khi build.
